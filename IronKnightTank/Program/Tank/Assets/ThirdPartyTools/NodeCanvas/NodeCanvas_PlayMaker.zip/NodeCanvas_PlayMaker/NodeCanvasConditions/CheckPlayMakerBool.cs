﻿#if UNITY_EDITOR
using UnityEditor;
#endif

using UnityEngine;
using System.Collections.Generic;
using HutongGames.PlayMaker;
using NodeCanvas.Variables;

namespace NodeCanvas.Conditions{

	[ScriptCategory("PlayMaker")]
	public class CheckPlayMakerBool : ConditionTask {

		[RequiredField]
		public PlayMakerFSM playmakerFSM;
		[RequiredField]
		public string boolName;

		public BBBool checkBool;

		protected override string conditionInfo{
			get
			{
				if (playmakerFSM == null)
					return "No PlayMakerFSM Selected";
				return "PlayMaker Bool '" + boolName + "' == " + checkBool;
			}
		}

		protected override bool OnCheck(){

			bool pmBool = playmakerFSM.FsmVariables.GetFsmBool(boolName).Value;
			return pmBool == checkBool.value;
		}


		////////////////////////////////////////
		///////////GUI AND EDITOR STUFF/////////
		////////////////////////////////////////
		#if UNITY_EDITOR
		
		protected override void OnConditionEditGUI(){

			playmakerFSM = EditorGUILayout.ObjectField("PlayMakerFSM", playmakerFSM, typeof(PlayMakerFSM), true) as PlayMakerFSM;

			if (playmakerFSM == null)
				return;

			FsmBool[] boolVariables = playmakerFSM.FsmVariables.BoolVariables;
			List<string> boolNames = new List<string>();
			foreach(FsmBool boolVar in boolVariables)
				boolNames.Add(boolVar.Name);

			boolName = EditorUtils.StringPopup("PlayMaker Bool", boolName, boolNames);
			checkBool = EditorUtils.BBValueField("Check Bool", checkBool) as BBBool;
		}
		
		#endif
	}
}