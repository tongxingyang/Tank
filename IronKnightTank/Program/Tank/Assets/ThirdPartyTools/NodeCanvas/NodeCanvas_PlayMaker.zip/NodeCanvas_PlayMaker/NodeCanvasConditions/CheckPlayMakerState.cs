﻿#if UNITY_EDITOR
using UnityEditor;
#endif

using UnityEngine;
using System.Collections.Generic;
using HutongGames.PlayMaker;

namespace NodeCanvas.Conditions{

	[ScriptCategory("PlayMaker")]
	public class CheckPlayMakerState : ConditionTask {

		[RequiredField]
		public PlayMakerFSM playmakerFSM;
		[RequiredField]
		public string stateName;

		protected override string conditionInfo{
			get
			{
				if (playmakerFSM == null)
					return "No PlayMakerFSM Selected";
				return  "PlayMaker State = '" + stateName + "'";
			}
		}

		protected override bool OnCheck(){

			if (playmakerFSM.ActiveStateName == stateName)
				return true;

			return false;
		}

		////////////////////////////////////////
		///////////GUI AND EDITOR STUFF/////////
		////////////////////////////////////////
		#if UNITY_EDITOR
		
		protected override void OnConditionEditGUI(){

			playmakerFSM = EditorGUILayout.ObjectField("PlayMakerFSM", playmakerFSM, typeof(PlayMakerFSM), true) as PlayMakerFSM;

			if (playmakerFSM == null)
				return;

			FsmState[] states = playmakerFSM.FsmStates;
			List<string> stateNames = new List<string>();
			foreach(FsmState state in states)
				stateNames.Add(state.Name);

			stateName = EditorUtils.StringPopup("State To Check", stateName, stateNames);
		}
		
		#endif
	}
}